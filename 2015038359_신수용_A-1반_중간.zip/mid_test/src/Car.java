/**
 * Created by shinsy1023 on 2016. 4. 30..
 */
class Car {
    String carNum;
    String kindOfCar;
}
